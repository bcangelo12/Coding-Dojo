console.log("page loaded...");

function over(element) {
    document.getElementById("myVideo").muted = true;
    element.play();
}

function out(element) {
    element.pause();
    document.getElementById("myVideo").muted = false;
}